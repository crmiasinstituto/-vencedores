
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/gerar-template.mjs
var GUIDELINES = `Voc\xEA gera pe\xE7as em HTML para a Comunidade + que Vencedores, do IAS Instituto (fundada por Isaac Santos). \xC9 uma comunidade de desenvolvimento pessoal, profissional, espiritual e financeiro.

TOM:
- Humano, pr\xF3ximo e inspirador. Nada de hype, nada de "cara de rob\xF4".
- Zero emoji. Nunca invente prova social (n\xFAmeros, nomes, depoimentos) que n\xE3o venham no brief.
- Portugu\xEAs brasileiro caloroso e direto. PROIBIDO travess\xE3o/em dash longo \u2014 use v\xEDrgula, ponto ou dois pontos.

DESIGN (marca azul, cabe\xE7alho em TEXTO, sem logo de imagem externa):
- Cabe\xE7alho: faixa azul (#1b3fd1), \xE0 esquerda o wordmark em texto branco: "<strong style="font-weight:800">+</strong> que Vencedores". Padding 18px 28px.
- Paleta: azul #1b3fd1, tinta #0b0e14, texto #3a4252, fundos #f4f6fb e #ffffff.
- Fonte: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif.
- Container central: max-width 640px, margin auto, fundo branco, border-radius 14px, border 1px solid #e6e9f2, overflow hidden.
- T\xEDtulos: font-weight 700, cor #0b0e14, 22-28px. Corpo: 15-16px, line-height 1.7, cor #3a4252.
- Bot\xE3o/CTA (quando fizer sentido): fundo #1b3fd1, texto branco, padding 14px 32px, border-radius 10px, font-weight 700, sem sublinhado.
- Rodap\xE9 discreto ao final: "IAS Instituto \u2014 Comunidade + que Vencedores".
- Use tabelas (role="presentation") pra compatibilidade com Gmail/Outlook quando o tipo for e-mail ou comunicado.
- Para "certificado": layout paisagem, moldura elegante, nome grande no centro, espa\xE7o pra assinatura de Isaac Santos.
- Placeholders entre colchetes pro que o brief n\xE3o definir: [Nome], [Data], [Link], [Detalhe]. Vari\xE1veis Mustache quando fizer sentido: {{primeiro_nome}}.

RESPONDA APENAS um JSON v\xE1lido (zero markdown, zero texto fora do JSON):
{
  "subject": "Assunto/t\xEDtulo curto (use {{primeiro_nome}} se for e-mail)",
  "preheader": "Uma linha de resumo/preview",
  "html_content": "<!DOCTYPE html>... HTML completo e autossuficiente, com todo o CSS inline"
}`;
var cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { ...cors, "Content-Type": "application/json" }
  });
}
function parseJsonLoose(text) {
  const t = String(text).trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  return JSON.parse(t);
}
var gerar_template_default = async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Use POST" }, 405);
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return json({ error: "ANTHROPIC_API_KEY n\xE3o configurada na Netlify" }, 500);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "JSON inv\xE1lido" }, 400);
  }
  const tipo = (body.tipo || "email").toString();
  const prompt = (body.prompt || "").toString().trim();
  const extra = (body.extra_context || "").toString().trim();
  if (!prompt) return json({ error: "Descreva o que voc\xEA quer gerar (campo prompt)." }, 400);
  const userText = `Tipo de pe\xE7a: ${tipo}.

Brief:
"${prompt}"
` + (extra ? `
Contexto adicional a respeitar:
${extra}
` : "") + `
Gere a pe\xE7a completa seguindo o padr\xE3o da marca. Retorne APENAS o JSON especificado.`;
  let res;
  try {
    res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model: "claude-sonnet-5",
        max_tokens: 4096,
        system: GUIDELINES,
        messages: [{ role: "user", content: userText }]
      })
    });
  } catch (e) {
    return json({ error: `Falha ao chamar o Claude: ${e.message}` }, 502);
  }
  if (!res.ok) {
    const err = await res.text();
    return json({ error: `Claude ${res.status}: ${err.slice(0, 300)}` }, 502);
  }
  const data = await res.json();
  const text = Array.isArray(data?.content) ? data.content.find((b) => b?.type === "text")?.text : void 0;
  if (!text) return json({ error: "Claude n\xE3o retornou conte\xFAdo." }, 502);
  let parsed;
  try {
    parsed = parseJsonLoose(text);
  } catch {
    return json({ error: "Claude retornou um formato inesperado. Tente de novo." }, 502);
  }
  const clean = (s) => String(s || "").replace(/—/g, ",");
  return json({
    success: true,
    provider: "claude",
    subject: clean(parsed.subject),
    preheader: clean(parsed.preheader),
    html_content: clean(parsed.html_content)
  });
};
export {
  gerar_template_default as default
};
