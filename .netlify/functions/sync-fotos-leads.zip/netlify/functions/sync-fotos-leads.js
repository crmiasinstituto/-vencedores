var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/sync-fotos-leads.mjs
var sync_fotos_leads_exports = {};
__export(sync_fotos_leads_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sync_fotos_leads_exports);
var cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
var json = (body, status = 200) => ({
  statusCode: status,
  headers: { ...cors, "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var soDigitos = (s) => String(s || "").replace(/\D/g, "");
async function handler(event) {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return json({ error: "method_not_allowed" }, 405);
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!SUPABASE_URL || !SERVICE_KEY) {
    return json({ error: "Servidor sem SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY" }, 500);
  }
  const { limite = 60, refazer = false } = JSON.parse(event.body || "{}");
  const sb = (caminho, init = {}) => fetch(`${SUPABASE_URL}/rest/v1/${caminho}`, {
    ...init,
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
      "Content-Type": "application/json",
      ...init.headers || {}
    }
  });
  const instRes = await sb("whatsapp_instances?provider=eq.uazapi&select=id,instance_token,api_url&limit=1");
  const [inst] = await instRes.json();
  if (!inst?.instance_token) return json({ error: "Sem inst\xE2ncia UAZAPI com token" }, 424);
  const uazUrl = inst.api_url || "https://squaad.uazapi.com";
  const filtro = refazer ? "whatsapp=not.is.null" : "whatsapp=not.is.null&or=(whatsapp_profile_pic_url.is.null,whatsapp_profile_pic_url.not.like.*supabase*)";
  const leadsRes = await sb(
    `crm_leads?${filtro}&select=id,whatsapp,name&order=updated_at.desc&limit=${Math.min(limite, 200)}`
  );
  const leads = await leadsRes.json();
  if (!Array.isArray(leads) || !leads.length) {
    return json({ ok: true, processados: 0, motivo: "nenhum lead pendente" });
  }
  let comFoto = 0;
  let semFoto = 0;
  let erros = 0;
  for (const lead of leads) {
    const numero = soDigitos(lead.whatsapp);
    if (numero.length < 10) {
      semFoto++;
      continue;
    }
    try {
      const r = await fetch(`${uazUrl}/chat/GetNameAndImageURL`, {
        method: "POST",
        headers: { token: inst.instance_token, "Content-Type": "application/json" },
        body: JSON.stringify({ number: numero, preview: false })
      });
      const dados = await r.json().catch(() => ({}));
      const urlFoto = dados?.image || dados?.imagePreview;
      if (!urlFoto) {
        semFoto++;
        continue;
      }
      const img = await fetch(urlFoto);
      if (!img.ok) {
        erros++;
        continue;
      }
      const bytes = Buffer.from(await img.arrayBuffer());
      const mime = img.headers.get("content-type") || "image/jpeg";
      const caminho = `perfis/${numero}.jpg`;
      const up = await fetch(`${SUPABASE_URL}/storage/v1/object/chat-media/${caminho}`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${SERVICE_KEY}`,
          "Content-Type": mime,
          "x-upsert": "true"
        },
        body: bytes
      });
      if (!up.ok) {
        erros++;
        continue;
      }
      const publica = `${SUPABASE_URL}/storage/v1/object/public/chat-media/${caminho}`;
      const patch = { whatsapp_profile_pic_url: publica, updated_at: (/* @__PURE__ */ new Date()).toISOString() };
      const semNome = !lead.name || /^\+?\d[\d\s()-]*$/.test(lead.name) || lead.name === "Sem nome";
      if (semNome && dados?.name) patch.name = dados.name;
      await sb(`crm_leads?id=eq.${lead.id}`, {
        method: "PATCH",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify(patch)
      });
      comFoto++;
      await new Promise((r2) => setTimeout(r2, 350));
    } catch (e) {
      console.error(`[foto] lead ${lead.id}: ${e.message}`);
      erros++;
    }
  }
  return json({ ok: true, processados: leads.length, comFoto, semFoto, erros });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
