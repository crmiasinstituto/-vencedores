
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/captura-lead.mjs
var cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type, x-lead-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
var json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...cors, "Content-Type": "application/json" } });
var first = (obj, keys) => {
  for (const k of keys) {
    const v = obj?.[k];
    if (v !== void 0 && v !== null && String(v).trim() !== "") return String(v).trim();
  }
  return "";
};
var captura_lead_default = async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ ok: false, error: "Use POST" }, 405);
  const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) {
    return json({ ok: false, error: "Servidor sem SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY" }, 500);
  }
  let body = {};
  try {
    body = await req.json();
  } catch {
  }
  const expected = process.env.LEAD_CAPTURE_TOKEN;
  if (expected) {
    const got = new URL(req.url).searchParams.get("token") || req.headers.get("x-lead-token") || body.token;
    if (got !== expected) return json({ ok: false, error: "token inv\xE1lido" }, 401);
  }
  const nome = first(body, ["nome", "name", "nome_completo", "full_name"]);
  const email = first(body, ["email", "e-mail", "mail"]);
  const telefone = first(body, ["telefone", "phone", "whatsapp", "celular", "cellphone", "fone"]);
  if (!nome && !email && !telefone) {
    return json({ ok: false, error: "Informe ao menos nome, email ou telefone." }, 400);
  }
  let res;
  try {
    res = await fetch(`${url}/rest/v1/rpc/capturar_lead_inscricao`, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ p_nome: nome || null, p_email: email || null, p_telefone: telefone || null })
    });
  } catch (e) {
    return json({ ok: false, error: `Falha ao gravar no CRM: ${e.message}` }, 502);
  }
  if (!res.ok) {
    const err = await res.text();
    return json({ ok: false, error: `CRM ${res.status}: ${err.slice(0, 200)}` }, 502);
  }
  const id = await res.json();
  return json({ ok: true, id });
};
export {
  captura_lead_default as default
};
